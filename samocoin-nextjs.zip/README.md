# SamoCoin Landing Page (Next.js + Tailwind + shadcn/ui)

## خطوات التشغيل:

1. تأكد من تثبيت Node.js
2. افتح التيرمنال داخل هذا المجلد وشغّل:
   npm install
   npm run dev

3. افتح المتصفح على:
   http://localhost:3000

تم إعداد الواجهة باستخدام Next.js 14، Tailwind CSS، و shadcn/ui.
