
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail } from "lucide-react";
import { motion } from "framer-motion";

export default function SamoCoinLanding() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <header className="flex justify-between items-center p-6 border-b border-gray-800">
        <div className="text-2xl font-bold">🧬 SamoCoin</div>
        <nav className="space-x-6">
          <a href="#about" className="hover:text-yellow-400">عن المشروع</a>
          <a href="#roadmap" className="hover:text-yellow-400">خارطة الطريق</a>
          <a href="#whitepaper" className="hover:text-yellow-400">المستند التقني</a>
          <a href="#contact" className="hover:text-yellow-400">تواصل معنا</a>
        </nav>
      </header>

      <section className="text-center py-20 bg-gradient-to-b from-black to-gray-900">
        <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-4xl md:text-6xl font-bold mb-4">
          العملة التي تعيد كتابة الشيفرة المالية
        </motion.h1>
        <p className="text-gray-400 text-lg mb-6">مدعومة بشبكة سولانا — SMC تقود الثورة المالية القادمة</p>
        <div className="space-x-4">
          <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold">اشترِ SMC</Button>
          <Button variant="outline" className="border-yellow-500 text-yellow-500 hover:bg-yellow-800">اقرأ المستند التقني</Button>
        </div>
      </section>

      <section id="about" className="py-20 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">ما هي SamoCoin؟</h2>
        <p className="text-gray-300 text-lg">
          SamoCoin (SMC) هي عملة رقمية متطورة مبنية على شبكة سولانا، تهدف إلى الدمج بين التقنية، التمويل الحيوي، والحرية المالية من خلال بنية لامركزية قوية وسريعة.
        </p>
      </section>

      <section className="grid md:grid-cols-2 gap-8 py-20 px-6 max-w-5xl mx-auto">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">سرعة تحويل فورية</CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">رسوم منخفضة جدًا</CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">حماية بالذكاء الاصطناعي</CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">تكامل مع محافظ سولانا مثل Phantom وSolflare</CardContent>
        </Card>
      </section>

      <section id="roadmap" className="py-20 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-6">خارطة الطريق</h2>
        <ul className="list-disc list-inside text-gray-300 space-y-2">
          <li>Q2 2025: إطلاق SamoCoin</li>
          <li>Q3 2025: تطوير تطبيق المحفظة</li>
          <li>Q4 2025: إطلاق SamoDAO</li>
          <li>2026: إطلاق منصة SamoDEX للتداول اللامركزي</li>
        </ul>
      </section>

      <section id="contact" className="py-20 px-6 bg-gray-900">
        <h2 className="text-2xl font-semibold mb-4">اشترك في النشرة البريدية</h2>
        <div className="flex gap-4 max-w-xl">
          <Input type="email" placeholder="أدخل بريدك الإلكتروني" className="bg-black text-white border-gray-700" />
          <Button className="bg-yellow-500 text-black font-bold flex items-center gap-2">
            <Mail className="w-4 h-4" /> اشترك
          </Button>
        </div>
      </section>

      <footer className="text-center text-gray-500 py-6 border-t border-gray-800">
        &copy; 2025 SamoCoin – جميع الحقوق محفوظة
      </footer>
    </div>
  );
}
